/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectomatricula;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author
 */
public class ProyectoMatricula {

    static List<Matricula> listMatricualas = new ArrayList();
    static Integer CANTIDAD = 2;
    
    static String[] usuario = new String[CANTIDAD];
    static int[] matricula = new int[CANTIDAD];

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Forma con clases
//        SolitarUsuario();
//        String nom = asignarDato(true);
//        imprimeMatriculaUsuario(nom);        
//        imprimeTodo();

        //Forma con arreglos
        SolitarUsuarioArreglo();

        String name = asignarDato(true);
        buscarUsuario(name);
                
        mostrarTodo();

    }

    //Forma con Arreglos
    public static void SolitarUsuarioArreglo() {

        for (int i = 0; i < 2; i++) {
            usuario[i] = asignarDato(true);
            matricula[i] = Integer.parseInt(asignarDato(false));
        }
    }

    public static void buscarUsuario(String nombre) {
        for (int i = 0; i < usuario.length; i++) {
            if (usuario[i].equals(nombre)) {
                System.out.println("El usuario: " + usuario[i] + ", matriculo: " + matricula[i]);
            }
        }
        
        System.out.println("");
    }

    public static void mostrarTodo() {
        System.out.println("Listado de los usuarios y matriculas");
        for (int i = 0; i < usuario.length; i++) {
            System.out.println("El usuario: " + usuario[i] + ", matriculo: " + matricula[i]);

        }
    }

    /*Forma con clases*/
    public static void SolitarUsuario() {

        for (int i = 0; i < 2; i++) {
            Matricula miMatr = new Matricula();
            miMatr.Usuario = asignarDato(true);
            miMatr.Cantidad = Integer.parseInt(asignarDato(false));
            listMatricualas.add(miMatr);
        }
    }

    public static void imprimeMatriculaUsuario(String nombre) {

        for (int i = 0; i < listMatricualas.size(); i++) {
            if (listMatricualas.get(i).Usuario.equals(nombre)) {
                System.out.println("El usuario: " + listMatricualas.get(i).Usuario + ", matriculo: " + listMatricualas.get(i).Cantidad);
            }
        }
    }

    public static void imprimeTodo() {
        System.out.println("Listado de los usuarios y matriculas");
        for (int i = 0; i < listMatricualas.size(); i++) {
            System.out.println("El usuario: " + listMatricualas.get(i).Usuario + ", matriculo: " + listMatricualas.get(i).Cantidad);
        }
    }

    //Metodos Auxiliares
    private static String asignarDato(boolean usuario) {
        String respuesta = "";

        if (usuario) {
            respuesta = JOptionPane.showInputDialog("Digite el nombre del Usuario");
        } else {
            respuesta = JOptionPane.showInputDialog("Digite Cantidad Matriculas");
        }
        return respuesta;
    }
    
    

}
